<?php // Silent is golden and we believe it ;)

