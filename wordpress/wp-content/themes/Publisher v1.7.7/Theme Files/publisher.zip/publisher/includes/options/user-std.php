<?php

/**
 * => Style
 */
$fields['avatar']                 = array(
	'std' => '',
);
$fields['page_layout']            = array(
	'std' => 'default',
);
$fields['page_listing']           = array(
	'std' => 'default',
);
$fields['page_listing_excerpt']   = array(
	'std' => 'default',
);
$fields['author_posts_count']     = array(
	'std' => '',
);
$fields['author_pagination_type'] = array(
	'std' => 'default',
);

/**
 * => Social Links
 */
$fields['twitter_url']    = array(
	'std' => '',
);
$fields['facebook_url']   = array(
	'std' => '',
);
$fields['gplus_url']      = array(
	'std' => '',
);
$fields['youtube_url']    = array(
	'std' => '',
);
$fields['linkedin_url']   = array(
	'std' => '',
);
$fields['github_url']     = array(
	'std' => '',
);
$fields['pinterest_url']  = array(
	'std' => '',
);
$fields['dribbble_url']   = array(
	'std' => '',
);
$fields['vimeo_url']      = array(
	'std' => '',
);
$fields['delicious_url']  = array(
	'std' => '',
);
$fields['soundcloud_url'] = array(
	'std' => '',
);
$fields['behance_url']    = array(
	'std' => '',
);
$fields['flickr_url']     = array(
	'std' => '',
);
$fields['instagram_url']  = array(
	'std' => '',
);


/**
 * -> Custom CSS
 */
$fields['_custom_css_code']                  = array(
	'std' => '',
);
$fields['_custom_css_class']                 = array(
	'std' => '',
);
$fields['_custom_css_desktop_code']          = array(
	'std' => '',
);
$fields['_custom_css_tablet_landscape_code'] = array(
	'std' => '',
);
$fields['_custom_css_tablet_portrait_code']  = array(
	'std' => '',
);
$fields['_custom_css_phones_code']           = array(
	'std' => '',
);
