<div
	class="bf-section-container vc-input bf-clearfix <?php echo isset( $options['section_class'] ) ? esc_attr( $options['section_class'] ) : ''; ?>">
	<?php echo $input; // escaped before ?>
</div>