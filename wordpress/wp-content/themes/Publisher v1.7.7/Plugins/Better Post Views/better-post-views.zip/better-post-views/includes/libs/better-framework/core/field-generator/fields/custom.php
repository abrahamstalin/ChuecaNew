<?php

if ( isset( $options['input_callback'] ) ) {
	if ( is_string( $options['input_callback'] ) && is_callable( $options['input_callback'] ) ) {
		$options['options'] = call_user_func( $options['input_callback'] );
	} elseif ( is_array( $options['input_callback'] ) && ! empty( $options['input_callback']['callback'] ) && is_callable( $options['input_callback']['callback'] ) ) {
		if ( isset( $options['input_callback']['args'] ) ) {
			$options['options'] = call_user_func_array( $options['input_callback']['callback'], $options['input_callback']['args'] );
		} else {
			$options['options'] = call_user_func( $options['input_callback']['callback'] );
		}
	}
} else if ( isset( $options['input'] ) ) {
	echo $options['input'];  // escaped before
}


if ( isset( $options['js-code'] ) ) {
	Better_Framework()->assets_manager()->add_admin_js( $options['js-code'] );
}

if ( isset( $options['css-code'] ) ) {
	Better_Framework()->assets_manager()->add_admin_css( $options['css-code'] );
}