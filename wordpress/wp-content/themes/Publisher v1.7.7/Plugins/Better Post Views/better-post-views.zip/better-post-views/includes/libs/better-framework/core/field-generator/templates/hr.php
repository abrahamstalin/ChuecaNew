<div class="bf-section-container bf-clearfix">
	<div class="bf-section-hr bf-clearfix">
		<?php echo $input; // escaped before ?>
	</div>
</div>