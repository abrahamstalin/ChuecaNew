<div class="info-value">
	<?php echo $options['value']; // escaped before ?>
</div>