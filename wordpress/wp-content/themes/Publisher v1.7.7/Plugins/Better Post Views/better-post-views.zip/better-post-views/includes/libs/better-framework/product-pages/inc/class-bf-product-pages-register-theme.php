<?php

class BF_Product_Pages_Register_Theme extends BF_Product_Item {

	public $id = 'register-theme';

	public function render_content( $item_data ) {
	}


	public function item_data() {
	}
}