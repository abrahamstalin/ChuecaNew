=== Better AMP - WordPress Complete AMP ===
Contributors: betterstudio
Donate link: http://betterstudio.com/
Tags: amp,accelerated mobile pages, mobile theme, google amp
Requires at least: 3.0
Tested up to: 4.7.2
Stable tag: 4.7.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Complete AMP solution for WordPress. It supports everything in WP.

== Description ==

This plugin is most complete AMP ( Google Accelerated Mobile Pages) support for WordPress with supporting everything and created in speed mater and will load faster than all other AMP plugins.

[Online Demo](http://demo.betterstudio.com/publisher/amp-demo/) | [Support](https://github.com/better-studio/better-amp/)

All pages, posts, categories, tags, author page, search... are supported in BetterAMP and there is a lot of more options that you can use them in customizer with live preview.


Also BetterAMP supports RTL languages completely.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/better-amp` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Settings->Better AMP screen to configure the plugin
1. (Make your instructions match the desired user flow for activating and installing your plugin. Include any steps that might be needed for explanatory purposes)


== Frequently Asked Questions ==

= What is the URL for AMP pages? =

You can see AMP version of your site with adding /amp/ to your site url: domain.com/amp/
All inner pages url will be started with same /amp/ in start of url: domain.com/amp/category/fashion
Also BetterAMP supports the /amp/ in the end of url to cover "Automatic AMP" plugin urls. 


== Screenshots ==
1. Homepage + Slider + Off-Canvas Navigation + Contact Info + Social Links
2. Post (Supports all post types) + Social Share + Share Count + Comments
3. Category Archive + Tag Archive + 2 type of listings
4. Search Result + Author Archive
5. Page (Contact page) + 404 page

== Changelog ==

= 1.2.2 =
- Added: Video/Audio Featured support added to AMP.
- Added: AMP Youtube, Twitter, Facebook, Vimeo, Soundcloud, Vine and Instagram support added.
- Fixed: Thumbnail of static pages fixed to be responsive.


= 1.2.1 =
* Added: 'Better WordPress Minify' plugin Compatibility.
* Fixed: Search page style issue fixed.


= 1.2.0 =
* Added: AMP Smart style printing. 200% smaller CSS file
* Added: Option to show/hide share in pages.

* Improved: AMP content validator layer improved.
* Improved: Design.

* Fixed: Blockquote style.
* Fixed: Home slider RTL style fixed.
* Fixed: Whatsapp link not works.
* Fixed: AMP changed to amp for third-party plugins compatibility.
* Fixed: Only 1 gallery is showing.
* Fixed: RTL style fixed.


= 1.1.3 =
* Improved: WP-Rocket compatibility improved.
* Fixed: Auto validator fixed for iFrame tag attrs.
* Fixed: Share link changed to none-AMP version link.
* Fixed: Script tags making page invalid fixed.
* Fixed: Post image is not showing fixed.


= 1.1.2 =
* Improved: RTL style checked and fixed for all pages.
* Fixed: Large listing image style.
* Fixed: Subtitle wrong tag close.
* Fixed: Google Analytics not works.
* Fixed: Missing close tag for <head>


= 1.1.1 =
* Fixed: "WP Rocket" plugin lazy load compatibility.
* Fixed: "Lazy Load" plugin compatibility.
* Fixed: "Lazy Load XT" plugin compatibility.
* Fixed: Customizer page not showing correctly.
* Fixed: Scroll to end customizer page issue.


= 1.1.0 =
* 10 Ad Location added.
* Ad Location 1: After header (in all pages)
* Ad Location 2: Before post title
* Ad Location 3: After post title
* Ad Location 4: Above post content
* Ad Location 5: Post content ads (After X Paragraph)
* Ad Location 6: Below post content
* Ad Location 7: After comments in posts
* Ad Location 8: Footer (in all pages)
* Ad Location 9: After title in archive pages
* Ad Location 10: After X posts in archive pages

* Added: New level of AMP page validator added.
* This validator includes all Google AMP rules and will make your site
* content validated with 99% warranty!

* Added: WooCommerce support added (Shop, Product, Shop Categories, Shop tags and Cart page)
* Added: Attachment page support added.

* Added: Custom css field added.

* Improvement: Style file printing changed.

* Fixed: A lof of code fix and improvement.
* Fixed: undefined function fixed.
* Fixed: Url encode added to make sure shared url will work correctly in social networks in RTL languages.
* Fixed: Share link changed to pretty permalink.
* Fixed: rel=amphtml generating for non-amp pages fixed.
* Fixed: Showing BetterStudio themes mega menu disabled in AMP.
* Fixed: Social share sorter fixed in customizer.

= 1.0.4 =
* Fix: Fatal error in creating new post.

= 1.0.3 =
* Fix: The undefined index warning in admin.

= 1.0.2 =
* Fix: Search page issue
* Improvement: Style improved.

= 1.0.1 =
* Fix: Menu item is not showing. 

= 1.0 =
* Public release

== Upgrade Notice ==

= 1.0 =
Nothing
