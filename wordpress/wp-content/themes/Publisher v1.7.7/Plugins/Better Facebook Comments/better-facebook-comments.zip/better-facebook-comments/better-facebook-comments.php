<?php
/*
Plugin Name: Better Facebook Comments
Plugin URI: http://betterstudio.com
Description: Take advantage of powerful and unique features by integrating Facebook comments on your website instead of the standard WordPress commenting system.
Version: 1.4.2
Author: BetterStudio
Author URI: http://betterstudio.com
License: GPL2
*/


/**
 * Better_Facebook_Comments class wrapper for make changes safe in future
 *
 * @return Better_Facebook_Comments
 */
function Better_Facebook_Comments() {
	return Better_Facebook_Comments::self();
}


// Initialize Better Facebook Comments
Better_Facebook_Comments();


/**
 * Class Better_Facebook_Comments
 */
class Better_Facebook_Comments {


	/**
	 * Contains Better_Facebook_Comments version number that used for assets for preventing cache mechanism
	 *
	 * @var string
	 */
	private static $version = '1.4.2';


	/**
	 * Contains plugin option panel ID
	 *
	 * @var string
	 */
	private static $panel_id = 'better_facebook_comments';


	/**
	 * Comments loading type: ajaxified|plain
	 *
	 * @var string
	 */
	private $comments_type;

	/**
	 * Inner array of instances
	 *
	 * @var array
	 */
	protected static $instances = array();


	function __construct() {

		// make sure following code only one time run
		static $initialized;
		if ( $initialized ) {
			return;
		} else {
			$initialized = TRUE;
		}

		// Admin panel options
		include self::dir_path( 'includes/options/panel.php' );

		// Initialize
		add_action( 'better-framework/after_setup', array( $this, 'bf_init' ) );

		load_plugin_textdomain( 'better-studio', FALSE, 'better-facebook-comments/languages' );

	}


	/**
	 * Used for accessing plugin directory URL
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public static function dir_url( $address = '' ) {

		static $url;

		if ( is_null( $url ) ) {
			$url = plugin_dir_url( __FILE__ );
		}

		return $url . $address;
	}


	/**
	 * Used for accessing plugin directory path
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public static function dir_path( $address = '' ) {

		static $path;

		if ( is_null( $path ) ) {
			$path = plugin_dir_path( __FILE__ );
		}

		return $path . $address;
	}


	/**
	 * Returns plugin current Version
	 *
	 * @return string
	 */
	public static function get_version() {

		return self::$version;

	}


	/**
	 * Build the required object instance
	 *
	 * @param   string $object
	 * @param   bool   $fresh
	 * @param   bool   $just_include
	 *
	 * @return  Better_Facebook_Comments|null
	 */
	public static function factory( $object = 'self', $fresh = FALSE, $just_include = FALSE ) {

		if ( isset( self::$instances[ $object ] ) && ! $fresh ) {
			return self::$instances[ $object ];
		}

		switch ( $object ) {

			/**
			 * Main Better_Facebook_Comments Class
			 */
			case 'self':
				$class = 'Better_Facebook_Comments';
				break;

			default:
				return NULL;
		}


		// Just prepare/includes files
		if ( $just_include ) {
			return;
		}

		// don't cache fresh objects
		if ( $fresh ) {
			return new $class;
		}

		self::$instances[ $object ] = new $class;

		return self::$instances[ $object ];
	}


	/**
	 * Used for accessing alive instance of Better_Facebook_Comments
	 *
	 * @since 1.0
	 *
	 * @return Better_Facebook_Comments
	 */
	public static function self() {

		return self::factory();

	}


	/**
	 * Used for retrieving options simply and safely for next versions
	 *
	 * @param $option_key
	 *
	 * @return mixed|null
	 */
	public static function get_option( $option_key ) {
		return bf_get_option( $option_key, self::$panel_id );
	}


	/**
	 *  Init the plugin
	 */
	function bf_init() {

		if ( is_admin() ) {
			if ( $this->get_option( 'app_id' ) && function_exists( 'Better_Disqus_Comments' ) && Better_Disqus_Comments()->get_option( 'shortname' ) ) {
				Better_Framework()->admin_notices()->add_notice( array(
					'id'  => 'facebook-and-disqus-same-time',
					'msg' => __( 'You activated both <strong>Facebook Comments</strong> and <strong>Disqus Comments</strong>. Please ensure that only one comment plugin is active at a time.', 'better-studio' )
				) );
			} else {
				Better_Framework()->admin_notices()->remove_notice( 'facebook-and-disqus-same-time' );
			}
		}

		if ( $this->get_option( 'app_id' ) === '' ) {
			return;
		}

		// Change default template
		add_filter( 'comments_template', array( $this, 'custom_comments_template' ), 40 );

		// Add ajax action to do views increment
		add_action( 'wp_ajax_better_facebook_comments', array( $this, 'clear_comments_cache' ) );
		add_action( 'wp_ajax_nopriv_better_facebook_comments', array( $this, 'clear_comments_cache' ) );

		if ( ! is_admin() ) {
			// Add App ID Meta
			add_action( 'wp_head', array( $this, 'wp_head' ) );

			// Clear themes comments count text in meta
			add_filter( 'better-studio/themes/meta/comments/text', array(
				$this,
				'better_studio_themes_comment_text'
			) );

			// Enqueue assets
			add_action( 'wp_enqueue_scripts', array( $this, 'wp_enqueue_scripts' ) );

			// Add JS
			add_action( 'wp_footer', array( $this, 'wp_footer' ) );

		}
	}


	/**
	 * Callback: Used for adding JS and CSS files to page
	 *
	 * Action: wp_enqueue_scripts
	 */
	function wp_enqueue_scripts() {

		$dir_url  = self::dir_url();
		$dir_path = self::dir_path();

		bf_enqueue_script(
			'better-facebook-comments',
			bf_append_suffix( $dir_url . 'js/better-facebook-comments', '.js' ),
			array( 'jquery' ),
			bf_append_suffix( $dir_path . 'js/better-facebook-comments', '.js' ),
			self::$version
		);

		bf_localize_script(
			'better-facebook-comments',
			'better_facebook_comments_vars',
			apply_filters(
				'better-facebook-comments/js/global-vars',
				array(
					'text_0'    => self::get_option( 'text_no_comment' ),
					'text_1'    => self::get_option( 'text_one_comment' ),
					'text_2'    => self::get_option( 'text_two_comment' ),
					'text_more' => self::get_option( 'text_comments' ),
				)
			)
		);

	}


	/**
	 *  Add FB js and tags
	 */
	function wp_footer() {

		// Add Facebook js and tags
		if ( is_singular() ) {

			ob_start();
			?>
			<div id="fb-root"></div>
			<script>
				(function () {
					function appendFbScript() {
						var js, id = 'facebook-jssdk',
							fjs = document.getElementsByTagName('script')[0];

						if (document.getElementById(id)) return;
						js = document.createElement('script');
						js.id = id;
						js.src = "//connect.facebook.net/<?php echo $this->get_option( 'locale' ); ?>/sdk.js#xfbml=1&appId=<?php echo $this->get_option( 'app_id' ); ?>&version=v2.0";
						fjs.parentNode.insertBefore(js, fjs);

						window.fbAsyncInit = function () {
							FB.init({
								appId: '<?php echo $this->get_option( 'app_id' ); ?>',
								xfbml: true,
								version: 'v2.0'
							});
							FB.Event.subscribe('comment.create', function (comment_data) {
								update_comments_count();
							});
							FB.Event.subscribe('comment.remove', function (comment_data) {
								update_comments_count();
							});
							function update_comments_count(comment_data, comment_action) {
								jQuery.ajax({
									type: 'POST',
									dataType: 'json',
									url: '<?php echo admin_url( 'admin-ajax.php' ); ?>',
									data: {
										action: 'better_facebook_comments',
										post_id: '<?php the_ID(); ?>'
									}
								});
							}
						};
					}
					<?php
					if ( $this->comments_type === 'ajaxified' ) :
						echo 'jQuery(document).on("ajaxified-comments-loaded",appendFbScript);';
					else:
						echo 'appendFbScript();';
					endif;
					?>
				})();
			</script>
			<?php
		}
	}


	/**
	 * Finds appropriate template file and return path
	 * This make option to change template in themes
	 *
	 * @return string
	 */
	function get_template() {

		// Use theme specified template for search page
		if ( file_exists( get_template_directory() . '/better-facebook-comments.php' ) ) {
			return get_template_directory() . '/better-facebook-comments.php';
		}

		return $this->dir_path( 'templates/better-facebook-comments.php' );
	}


	/**
	 * Changes WP comments template with Facebook template
	 *
	 * @param string $template absolute path to comment template file
	 *
	 * @return string
	 */
	function custom_comments_template( $template ) {
		$is_ajaxified = basename( $template ) === 'comments-ajaxified.php';

		$this->comments_type = $is_ajaxified ? 'ajaxified' : 'plain';
		if ( $is_ajaxified ) {
			return $template;
		}

		return $this->get_template();
	}


	/**
	 * Ajax callback: clears comments count.
	 *
	 * @return string|void
	 */
	function clear_comments_cache() {

		if ( ! isset( $_POST['post_id'] ) ) {
			return;
		}

		delete_transient( 'bfc_post_' . $_POST['post_id'] );

		die();
	}


	/**
	 * Retrieves post Facebook comments count.
	 *
	 * @return int|mixed
	 */
	function get_comment_count() {

		$id = 'bfc_post_' . get_the_ID();

		if ( ( $count = get_transient( $id ) ) === FALSE ) {

			$request = wp_remote_get( 'https://graph.facebook.com/v2.1/?fields=share{comment_count}&id=' . esc_url( get_permalink() ) );

			if ( ! is_wp_error( $request ) ) {

				$request = json_decode( wp_remote_retrieve_body( $request ), TRUE );

				if ( isset( $request['error'] ) ) {
					$count = 0;
					set_transient( $id, $count, MINUTE_IN_SECONDS * 20 );
				} elseif ( ! empty( $request['share']['comment_count'] ) ) {
					$count = $request['share']['comment_count'];
					set_transient( $id, $count, HOUR_IN_SECONDS * 3 );
					add_post_meta( get_the_ID(), '_facebook_comments_count', $count, TRUE );
				}
			}
		}

		if ( $count === FALSE ) {
			if ( get_post_meta( get_the_ID(), '_facebook_comments_count', TRUE ) !== FALSE ) {
				$count = get_post_meta( get_the_ID(), '_facebook_comments_count', TRUE );
			} else {
				$count = 0;
			}
		}

		if ( empty( $count ) ) {
			$count = 0;
		}

		return $count;
	}


	/**
	 * Callback: Used to clear themes meta text to better style in front-end
	 *
	 * Filter: better-studio/themes/meta/comments/text
	 *
	 * @param $text
	 *
	 * @return string
	 */
	function better_studio_themes_comment_text( $text ) {
		return $this->get_comment_count();
	}


	/**
	 * Callback: Adds Facebook App data to header
	 *
	 * Action: wp_head
	 */
	function wp_head() {
		echo '<meta property="fb:app_id" content="' . $this->get_option( 'app_id' ) . '">';
	}
}
