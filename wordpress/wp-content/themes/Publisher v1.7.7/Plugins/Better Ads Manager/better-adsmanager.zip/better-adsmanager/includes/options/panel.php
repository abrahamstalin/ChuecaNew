<?php

add_filter( 'better-framework/panel/add', 'better_ads_manager_panel_add', 10 );

if ( ! function_exists( 'better_ads_manager_panel_add' ) ) {
	/**
	 * Callback: Ads panel
	 *
	 * Filter: better-framework/panel/options
	 *
	 * @param $panels
	 *
	 * @return array
	 */
	function better_ads_manager_panel_add( $panels ) {

		$panels['better_ads_manager'] = array(
			'id' => 'better_ads_manager',
		);

		return $panels;
	}
}


add_filter( 'better-framework/panel/better_ads_manager/config', 'better_ads_manager_panel_config', 10 );

if ( ! function_exists( 'better_ads_manager_panel_config' ) ) {
	/**
	 * Callback: Init's BF options
	 *
	 * @param $panel
	 *
	 * @return array
	 */
	function better_ads_manager_panel_config( $panel ) {

		include Better_Ads_Manager::dir_path( 'includes/options/panel-config.php' );

		return $panel;
	}
}


add_filter( 'better-framework/panel/better_ads_manager/fields', '_better_ads_options_post_ads_tab', 30 );

/**
 * Ads "Post Ads" tab to options
 *
 * @param $fields
 *
 * @return array
 */
function _better_ads_options_post_ads_tab( $fields ) {

	$fields[] = array(
		'name' => __( 'Post Ads', 'better-studio' ),
		'id'   => 'post_ads_tab',
		'type' => 'tab',
		'icon' => 'bsai-page-text',
	);

	return $fields;
}


add_filter( 'better-framework/panel/better_ads_manager/fields', '_better_ads_options_post_top_ads', 33 );

/**
 * Ads "Post Ads" tab to options
 *
 * @param $fields
 *
 * @return array
 */
function _better_ads_options_post_top_ads( $fields ) {

	better_ads_inject_ad_field_to_fields( $fields, array(
		'group'       => TRUE,
		'group_title' => __( 'Above Post Content', 'better-studio' ),
		'id_prefix'   => 'ad_post_top',
		'group_state' => 'close',
	) );

	return $fields;
}


add_filter( 'better-framework/panel/better_ads_manager/fields', '_better_ads_options_post_bottom_ads', 37 );

/**
 * Ads "Post Bottom Ads" to options
 *
 * @param $fields
 *
 * @return array
 */
function _better_ads_options_post_bottom_ads( $fields ) {

	better_ads_inject_ad_field_to_fields( $fields, array(
		'group'       => TRUE,
		'group_title' => __( 'Below Post Content', 'better-studio' ),
		'id_prefix'   => 'ad_post_bottom',
		'group_state' => 'close',
	) );

	return $fields;
}


add_filter( 'better-framework/panel/better_ads_manager/fields', '_better_ads_options_post_inline_ads', 33 );

/**
 * Ads "Post Ads" tab to options
 *
 * @param $fields
 *
 * @return array
 */
function _better_ads_options_post_inline_ads( $fields ) {

	include Better_Ads_Manager::dir_path( 'includes/options/panel-fields-inline.php' );

	return $fields;
}


add_filter( 'better-framework/panel/better_ads_manager/fields', '_better_ads_options_custom_css_js', 90 );

/**
 * Ads "Custom CSS/JS" to options
 *
 * @param $fields
 *
 * @return array
 */
function _better_ads_options_custom_css_js( $fields ) {

	include Better_Ads_Manager::dir_path( 'includes/options/panel-fields-css.php' );

	return $fields;
}


add_filter( 'better-framework/panel/better_ads_manager/fields', '_better_ads_options_import_export', 100 );

/**
 * Ads "Custom CSS/JS" to options
 *
 * @param $fields
 *
 * @return array
 */
function _better_ads_options_import_export( $fields ) {

	bf_inject_panel_import_export_fields( $fields, array(
		'panel-id'         => Better_Ads_Manager::$panel_id,
		'export-file-name' => 'better-ads-backup',
	) );

	return $fields;
}

add_filter( 'better-framework/panel/better_ads_manager/std', '_better_ads_options_std', 33 );

/**
 * Ads "Post Ads" tab to options
 *
 * @param $fields
 *
 * @return array
 */
function _better_ads_options_std( $fields ) {

	//  top ads
	$fields['ad_post_top_type']     = array(
		'std' => '',
	);
	$fields['ad_post_top_banner']   = array(
		'std' => 'none',
	);
	$fields['ad_post_top_campaign'] = array(
		'std' => 'none',
	);
	$fields['ad_post_top_count']    = array(
		'std' => 1,
	);
	$fields['ad_post_top_columns']  = array(
		'std' => 1,
	);
	$fields['ad_post_top_orderby']  = array(
		'std' => 'rand',
	);
	$fields['ad_post_top_order']    = array(
		'std' => 'ASC',
	);
	$fields['ad_post_top_align']    = array(
		'std' => 'center',
	);


	// Post Bottom
	$fields['ad_post_bottom_type']     = array(
		'std' => '',
	);
	$fields['ad_post_bottom_banner']   = array(
		'std' => 'none',
	);
	$fields['ad_post_bottom_campaign'] = array(
		'std' => 'none',
	);
	$fields['ad_post_bottom_count']    = array(
		'std' => 1,
	);
	$fields['ad_post_bottom_columns']  = array(
		'std' => 1,
	);
	$fields['ad_post_bottom_orderby']  = array(
		'std' => 'rand',
	);
	$fields['ad_post_bottom_order']    = array(
		'std' => 'ASC',
	);
	$fields['ad_post_bottom_align']    = array(
		'std' => 'center',
	);


	// Post inline
	$fields['ad_post_inline'] = array(
		'default' => array(
			array(
				'type'      => '',
				'campaign'  => 'none',
				'banner'    => 'none',
				'position'  => 'center',
				'paragraph' => 3,
				'count'     => 3,
				'columns'   => 3,
				'orderby'   => 'rand',
				'order'     => 'ASC',
			),
		),
		'std'     => array(
			array(
				'type'      => '',
				'campaign'  => 'none',
				'banner'    => 'none',
				'position'  => 'center',
				'paragraph' => 3,
				'count'     => 3,
				'columns'   => 3,
				'orderby'   => 'rand',
				'order'     => 'ASC',
			),
		),
	);


	// Custom code
	$fields['custom_css_code']    = array(
		'std' => '',
	);
	$fields['custom_header_code'] = array(
		'std' => '',
	);


	return $fields;
}

