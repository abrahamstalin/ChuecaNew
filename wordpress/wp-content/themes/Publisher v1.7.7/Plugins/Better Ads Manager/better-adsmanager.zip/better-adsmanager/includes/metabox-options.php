<?php

// Meta box options
add_filter( 'better-framework/metabox/options', 'better_ads_manager_metabox_options', 100 );


if ( ! function_exists( 'better_ads_manager_metabox_options' ) ) {

	/**
	 * Setup custom metaboxes for BetterMag
	 *
	 * @param $options
	 *
	 * @return array
	 */
	function better_ads_manager_metabox_options( $options ) {


		/**
		 * => Campaign Metabox
		 */
		$fields                                 = array();
		$fields['campaign_options']             = array(
			'name' => __( 'Campaign', 'better-studio' ),
			'id'   => 'campaign_options',
			'type' => 'tab',
			'icon' => 'bsai-gear',
		);
		$fields['desc']                         = array(
			'name'          => __( 'Campaign Note & Description', 'better-studio' ),
			'id'            => 'desc',
			'type'          => 'textarea',
			'std'           => '',
			'section_class' => 'full-with-both',
		);
		$options['better_ads_campaign_options'] = array(
			'config'   => array(
				'title'    => __( 'Better Campaign Options', 'better-studio' ),
				'pages'    => array( 'better-campaign' ),
				'context'  => 'normal',
				'prefix'   => FALSE,
				'priority' => 'high'
			),
			'panel-id' => Better_Ads_Manager::$panel_id,
			'fields'   => $fields
		);

		return $options;

	} //setup_bf_metabox

}

