<?php


add_filter( 'better-framework/metabox/add', 'better_ads_manager_metabox_add', 100 );

if ( ! function_exists( 'better_ads_manager_metabox_add' ) ) {
	/**
	 * Adds metabox to BF
	 *
	 * @param $metabox array
	 *
	 * @return array
	 */
	function better_ads_manager_metabox_add( $metabox ) {

		$metabox['better_ads_banner_options'] = array(
			'panel-id' => Better_Ads_Manager::$panel_id,
		);

		$metabox['better_ads_banner_campaign_options'] = array(
			'panel-id' => Better_Ads_Manager::$panel_id,
		);

		$metabox['better_ads_campaign_options'] = array(
			'panel-id' => Better_Ads_Manager::$panel_id,
		);

		return $metabox;
	}
}

add_filter( 'better-framework/metabox/better_ads_banner_options/config', 'better_ads_manager_metabox_banner_config', 10 );

if ( ! function_exists( 'better_ads_manager_metabox_banner_config' ) ) {
	/**
	 * Configs custom metaboxe
	 *
	 * @param $config
	 *
	 * @return array
	 */
	function better_ads_manager_metabox_banner_config( $config ) {

		return array(
			'title'    => __( 'Banner Options', 'better-studio' ),
			'pages'    => array( 'better-banner' ),
			'context'  => 'normal',
			'prefix'   => FALSE,
			'priority' => 'high'
		);

	} // better_ads_manager_metabox_config
} // if

add_filter( 'better-framework/metabox/better_ads_banner_options/std', 'better_ads_manager_metabox_std', 10 );

if ( ! function_exists( 'better_ads_manager_metabox_std' ) ) {
	/**
	 * Configs metaboxe STD's
	 *
	 * @param $fields
	 *
	 * @return array
	 */
	function better_ads_manager_metabox_std( $fields ) {

		include Better_Ads_Manager::dir_path( 'includes/options/metabox-std.php' );

		return $fields;
	}
}


add_filter( 'better-framework/metabox/better_ads_banner_options/fields', 'better_ads_manager_metabox_fields', 10 );

if ( ! function_exists( 'better_ads_manager_metabox_fields' ) ) {
	/**
	 * Configs metaboxe fields
	 *
	 * @param $fields
	 *
	 * @return array
	 */
	function better_ads_manager_metabox_fields( $fields ) {

		include Better_Ads_Manager::dir_path( 'includes/options/metabox-fields.php' );

		return $fields;
	}
}

if ( ! function_exists( 'better_ads_field_responsive_callback' ) ) {
	/**
	 * Callback for responsive field
	 *
	 * @since 1.4.1
	 */
	function better_ads_field_responsive_callback() {

		include Better_Ads_Manager::dir_path( 'includes/options/metabox-fields-responsive-cb.php' );

	} // better_ads_field_responsive_callback
}


add_filter( 'better-framework/metabox/better_ads_campaign_options/config', 'better_ads_manager_metabox_campaign_config', 10 );

if ( ! function_exists( 'better_ads_manager_metabox_campaign_config' ) ) {
	/**
	 * Configs custom metaboxe
	 *
	 * @param $config
	 *
	 * @return array
	 */
	function better_ads_manager_metabox_campaign_config( $config ) {

		return array(
			'title'    => __( 'Better Campaign Options', 'better-studio' ),
			'pages'    => array( 'better-campaign' ),
			'context'  => 'normal',
			'prefix'   => FALSE,
			'priority' => 'high'
		);

	} // better_ads_manager_metabox_config
} // if


add_filter( 'better-framework/metabox/better_ads_campaign_options/fields', 'better_ads_manager_metabox_campaign_fields', 10 );

if ( ! function_exists( 'better_ads_manager_metabox_campaign_fields' ) ) {
	/**
	 * Configs metaboxe fields
	 *
	 * @param $fields
	 *
	 * @return array
	 */
	function better_ads_manager_metabox_campaign_fields( $fields ) {

		$fields['campaign_options'] = array(
			'name' => __( 'Campaign', 'better-studio' ),
			'id'   => 'campaign_options',
			'type' => 'tab',
			'icon' => 'bsai-gear',
		);
		$fields['desc']             = array(
			'name'          => __( 'Campaign Note & Description', 'better-studio' ),
			'id'            => 'desc',
			'type'          => 'textarea',
			'section_class' => 'full-with-both',
		);

		return $fields;
	}
}


add_filter( 'better-framework/metabox/better_ads_campaign_options/std', 'better_ads_manager_metabox_campaign_std', 10 );

if ( ! function_exists( 'better_ads_manager_metabox_campaign_std' ) ) {
	/**
	 * Configs metaboxe fields
	 *
	 * @param $fields
	 *
	 * @return array
	 */
	function better_ads_manager_metabox_campaign_std( $fields ) {

		$fields['desc'] = array(
			'std' => '',
		);

		return $fields;
	}
}


add_filter( 'better-framework/metabox/better_ads_banner_campaign_options/config', 'better_ads_manager_metabox_banner_campaign_config', 10 );

if ( ! function_exists( 'better_ads_manager_metabox_banner_campaign_config' ) ) {
	/**
	 * Configs custom metaboxe
	 *
	 * @param $config
	 *
	 * @return array
	 */
	function better_ads_manager_metabox_banner_campaign_config( $config ) {

		return array(
			'title'    => __( 'Campaign of Ad', 'better-studio' ),
			'pages'    => array( 'better-banner' ),
			'context'  => 'side',
			'prefix'   => FALSE,
			'priority' => 'high'
		);

	} // better_ads_manager_metabox_config
} // if


add_filter( 'better-framework/metabox/better_ads_banner_campaign_options/fields', 'better_ads_manager_metabox_banner_campaign_fields', 10 );

if ( ! function_exists( 'better_ads_manager_metabox_banner_campaign_fields' ) ) {
	/**
	 * Configs metaboxe fields
	 *
	 * @param $fields
	 *
	 * @return array
	 */
	function better_ads_manager_metabox_banner_campaign_fields( $fields ) {

		$fields['campaign'] = array(
			'name'             => __( 'Select a campaign for this ad', 'better-studio' ),
			'id'               => 'campaign',
			'type'             => 'select',
			'section_class'    => 'full-with-both',
			'container_class'  => 'campaign-field',
			'deferred-options' => array(
				'callback' => 'better_ads_get_campaigns_option',
				'args'     => array(
					- 1,
					TRUE
				),
			),
			'section-css'      => array(
				'background' => '#f7f7f7'
			)
		);

		return $fields;
	}
}


add_filter( 'better-framework/metabox/better_ads_banner_campaign_options/std', 'better_ads_manager_metabox_banner_campaign_std', 10 );

if ( ! function_exists( 'better_ads_manager_metabox_banner_campaign_std' ) ) {
	/**
	 * Configs metaboxe fields
	 *
	 * @param $fields
	 *
	 * @return array
	 */
	function better_ads_manager_metabox_banner_campaign_std( $fields ) {

		$fields['campaign'] = array(
			'std' => '',
		);

		return $fields;
	}
}
