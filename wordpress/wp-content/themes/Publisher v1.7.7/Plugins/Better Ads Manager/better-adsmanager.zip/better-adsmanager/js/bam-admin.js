var Better_Ads_Manager_Admin = (function ($) {
    "use strict";

    return {

        init: function () {
            Better_Ads_Manager_Admin.update_responsive_fields();

            $('.bf-controls-image_radio-option  input[name="bf-metabox-option[better_ads_banner_options][type]"], .bf-controls-image_radio-option  input[name="bf-metabox-option[better_ads_banner_options][format]"]').on('change', function () {
                Better_Ads_Manager_Admin.update_responsive_fields();
            });
        },

        update_responsive_fields: function () {
            var type = $('.bf-controls-image_radio-option  input[name="bf-metabox-option[better_ads_banner_options][type]"]:checked').attr('value'),
                format = $('.bf-controls-image_radio-option  input[name="bf-metabox-option[better_ads_banner_options][format]"]:checked').attr('value'),
                $resp = $('.bf-section[data-id="responsive_options"] .better-ads-table');

            if (format == 'amp') {
                $('.responsive-field-container').slideUp();
            } else {

                $('.responsive-field-container').slideDown();

                if (type == 'code') {
                    $resp.addClass('show-sizes');
                } else {
                    $resp.removeClass('show-sizes')
                }

            }

        }

    };
})(jQuery);

// Load when ready
jQuery(document).ready(function () {
    Better_Ads_Manager_Admin.init();
});
